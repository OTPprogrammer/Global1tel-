"""
Auth endpoints — port of app/Auth/signin.php, public/api/auth.php and
public/api/session.php.

Routes kept identical so login.html needs no changes:
    /ints/signin?action=captcha|process|check|logout
    /api/auth.php?action=login|logout|check|captcha
    /api/session.php
"""
from __future__ import annotations

import math
import random
import time
from datetime import datetime, timedelta

from fastapi import APIRouter, Depends, Request

from core import config
from core.context import Ctx, get_ctx
from core.helpers import (
    generate_hash, generate_token, json_response, log_activity, sanitize, to_int,
)
from core.session import client_ip, guard

router = APIRouter()

ROLE_DASHBOARD = {
    "admin": "/ints/admin/AdminDashboard",
    "manager": "/ints/manager/SMSDashboard",
    "agent": "/ints/agent/SMSDashboard",
    "client": "/ints/client/SMSDashboard",
    "test": "/ints/test/SMSDashboard.html",
}


def dashboard_for(role: str) -> str:
    return ROLE_DASHBOARD.get(role, "/ints/client/SMSDashboard")


# ── captcha ─────────────────────────────────────────────────────────────────
def _generate_captcha(ctx: Ctx, wrap_key: bool = False):
    session_id = ctx.session.sid
    num1 = random.randint(0, 9)
    num2 = random.randint(0, 9)
    answer = num1 + num2

    expires_at = (datetime.utcnow() + timedelta(minutes=5)).strftime("%Y-%m-%d %H:%M:%S")
    ctx.db.query("DELETE FROM captcha_sessions WHERE session_id = ?", [session_id])
    ctx.db.query(
        "INSERT INTO captcha_sessions (session_id, captcha_answer, expires_at) VALUES (?, ?, ?)",
        [session_id, answer, expires_at],
    )

    payload = {"question": f"{num1} + {num2} = ?", "num1": num1, "num2": num2}
    if wrap_key:  # api/auth.php nested it under "captcha"
        return json_response({"success": True, "captcha": payload})
    return json_response({"success": True, **payload})


def _verify_captcha(ctx: Ctx, answer: int) -> bool:
    row = ctx.db.query(
        "SELECT captcha_answer FROM captcha_sessions WHERE session_id = ? AND expires_at > NOW()",
        [ctx.session.sid],
    ).fetch()
    return bool(row) and to_int(answer) == to_int(row["captcha_answer"])


# ── login ───────────────────────────────────────────────────────────────────
async def _process_login(ctx: Ctx, captcha_field: str, redirect_map):
    body = await ctx.body()
    username = sanitize(body.get("username") or "")
    password = body.get("password") or ""
    captcha_answer = to_int(body.get(captcha_field), 0)
    ip = client_ip(ctx.request)

    if not username or not password:
        return json_response({"error": "Username and password are required"}, 400)

    # Brute-force protection, same limits as the PHP LOGIN_RATE_LIMIT block.
    login_check = guard.check_login(ip, username)
    if not login_check.get("allowed"):
        minutes = math.ceil(login_check.get("remaining", 0) / 60)
        return json_response(
            {"error": f"Too many failed attempts. Please try again in {minutes} minutes.",
             "banned": True},
            429,
        )

    if not _verify_captcha(ctx, captcha_answer):
        guard.record_failed_login(ip, username)
        log_activity(None, "login_failed", f"Invalid captcha for username: {username}", ip)
        return json_response(
            {"error": "Invalid captcha answer",
             "attempts_remaining": max(0, login_check.get("remaining", 5) - 1)},
            400,
        )

    ctx.db.query("DELETE FROM captcha_sessions WHERE session_id = ?", [ctx.session.sid])

    hashed = generate_hash(password)
    user = ctx.db.query(
        "SELECT u.*, up.full_name, up.phone, up.timezone, up.avatar "
        "FROM users u LEFT JOIN user_profiles up ON u.id = up.user_id "
        "WHERE u.username = ? AND u.password = ? AND u.status = 'active'",
        [username, hashed],
    ).fetch()

    if not user:
        guard.record_failed_login(ip, username)
        log_activity(None, "login_failed", f"Invalid credentials for username: {username}", ip)
        return json_response(
            {"error": "Invalid username or password",
             "attempts_remaining": max(0, login_check.get("remaining", 5) - 1)},
            401,
        )

    guard.clear_login(ip, username)
    ctx.db.query("UPDATE users SET last_login = NOW(), login_ip = ? WHERE id = ?", [ip, user["id"]])

    ctx.session.update_many({
        "user_id": user["id"],
        "username": user["username"],
        "role": user["role"],
        "parent_id": user["parent_id"],
        "full_name": user.get("full_name"),
        "timezone": user.get("timezone"),
        "logged_in": True,
        "login_time": int(time.time()),
    })

    api_token = user.get("api_token")
    if not api_token:
        api_token = generate_token()
        ctx.db.query("UPDATE users SET api_token = ? WHERE id = ?", [api_token, user["id"]])

    log_activity(user["id"], "login", "User logged in successfully", ip)

    balances = ctx.db.query(
        "SELECT currency, balance FROM user_balances WHERE user_id = ?", [user["id"]]
    ).fetch_key_pair()

    return json_response({
        "success": True,
        "message": "Login successful",
        "redirect": redirect_map(user["role"]),
        "user": {
            "id": user["id"],
            "username": user["username"],
            "role": user["role"],
            "full_name": user.get("full_name"),
            "api_token": api_token,
            "balances": balances,
        },
    })


def _check_session(ctx: Ctx):
    if not ctx.session.logged_in:
        return json_response({"authenticated": False, "redirect": "/ints/login"}, 401)
    if ctx.session.expired():
        ctx.session.destroy()
        return json_response({"authenticated": False, "redirect": "/ints/login", "expired": True}, 401)

    user = ctx.db.query(
        "SELECT u.*, up.full_name, up.phone, up.timezone "
        "FROM users u LEFT JOIN user_profiles up ON u.id = up.user_id "
        "WHERE u.id = ? AND u.status = 'active'",
        [ctx.session.get("user_id")],
    ).fetch()
    if not user:
        ctx.session.destroy()
        return json_response({"authenticated": False, "redirect": "/ints/login"}, 401)

    balances = ctx.db.query(
        "SELECT currency, balance FROM user_balances WHERE user_id = ?", [user["id"]]
    ).fetch_key_pair()

    return json_response({
        "authenticated": True,
        "user": {
            "id": user["id"],
            "username": user["username"],
            "role": user["role"],
            "full_name": user.get("full_name"),
            "balances": balances,
        },
    })


def _logout(ctx: Ctx, redirect: str = "/ints/login"):
    user_id = ctx.session.get("user_id")
    if user_id:
        log_activity(user_id, "logout", "User logged out", client_ip(ctx.request))
    ctx.session.destroy()
    return json_response({"success": True, "message": "Logged out successfully", "redirect": redirect})


# ── /ints/signin  (app/Auth/signin.php) ─────────────────────────────────────
@router.api_route("/ints/signin", methods=["GET", "POST"])
async def ints_signin(request: Request, ctx: Ctx = Depends(get_ctx)):
    action = ctx.q("action") or (await ctx.value("action")) or "process"
    if action == "captcha":
        return _generate_captcha(ctx)
    if action == "process":
        return await _process_login(ctx, "capt", dashboard_for)
    if action == "check":
        return _check_session(ctx)
    if action == "logout":
        return _logout(ctx)
    return json_response({"error": "Invalid action"}, 400)


# ── /api/auth.php ───────────────────────────────────────────────────────────
@router.api_route("/api/auth.php", methods=["GET", "POST"])
@router.api_route("/api/auth", methods=["GET", "POST"])
async def api_auth(request: Request, ctx: Ctx = Depends(get_ctx)):
    action = ctx.q("action") or "login"
    if action == "login":
        # auth.php used the field name "captcha" and .html redirect targets.
        return await _process_login(ctx, "captcha", lambda role: dashboard_for(role) + ".html")
    if action == "logout":
        return _logout(ctx, "../ints/login.html")
    if action == "check":
        return _check_session(ctx)
    if action == "captcha":
        return _generate_captcha(ctx, wrap_key=True)
    return json_response({"error": "Invalid action"}, 400)


# ── /api/session.php ────────────────────────────────────────────────────────
@router.api_route("/api/session.php", methods=["GET", "POST"])
@router.api_route("/api/session", methods=["GET", "POST"])
async def api_session(request: Request, ctx: Ctx = Depends(get_ctx)):
    if not ctx.session.logged_in:
        return json_response({"authenticated": False, "redirect": "/ints/login"}, 401)
    if ctx.session.expired():
        ctx.session.destroy()
        return json_response({"authenticated": False, "redirect": "/ints/login", "expired": True}, 401)

    ctx.session.touch()

    user = ctx.db.query(
        "SELECT u.*, up.full_name, up.phone, up.timezone, up.avatar "
        "FROM users u LEFT JOIN user_profiles up ON u.id = up.user_id "
        "WHERE u.id = ? AND u.status = 'active'",
        [ctx.session.get("user_id")],
    ).fetch()
    if not user:
        ctx.session.destroy()
        return json_response({"authenticated": False, "redirect": "/ints/login"}, 401)

    balances = ctx.db.query(
        "SELECT currency, balance FROM user_balances WHERE user_id = ?", [user["id"]]
    ).fetch_key_pair()
    unread = to_int(ctx.db.query(
        "SELECT COUNT(*) as count FROM notifications WHERE user_id = ? AND is_read = 0", [user["id"]]
    ).scalar())

    return json_response({
        "success": True,
        "logged_in": True,
        "authenticated": True,
        "dashboard_url": dashboard_for(user["role"]),
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user.get("email"),
            "role": user["role"],
            "full_name": user.get("full_name"),
            "phone": user.get("phone"),
            "timezone": user.get("timezone"),
            "avatar": user.get("avatar"),
            "api_token": user.get("api_token"),
            "balances": balances,
            "unread_notifications": unread,
            "last_login": user.get("last_login"),
        },
    })
