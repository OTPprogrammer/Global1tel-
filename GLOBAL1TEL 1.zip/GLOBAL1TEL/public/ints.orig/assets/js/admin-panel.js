(function(){
'use strict';
const $=(s,r=document)=>r.querySelector(s), $$=(s,r=document)=>Array.from(r.querySelectorAll(s));
const api='/api/admin.php';
let adminUser=null;
let smppProfiles=[];
let agentNewsRows=[];
let rangeRows=[];
let globalAgentRows=[];
const roleMeta={
  manager:{body:'#managersBody',search:'#managerSearch',status:'#managerStatus'},
  agent:{body:'#agentsBody',search:'#agentSearch',status:'#agentStatus'},
  client:{body:'#clientsBody',search:'#clientSearch',status:'#clientStatus'},
  test:{body:'#testBody',search:'#testSearch',status:'#testStatus'}
};
const titles={
  dashboard:['Dashboard','Global system overview'],
  managers:['Managers','Create and control Manager accounts'],
  agents:['Agents','All Agents across every Manager'],
  clients:['Clients','All Clients across every Agent'],
  test:['Test Accounts','Separate Test-role accounts controlled by Admin'],
  ranges:['SMS Ranges','Admin-owned range creation and number import'],
  numbers:['All Numbers','Global number inventory'],
  reports:['SMS / OTP Stats','CDR metadata and masked OTP-event analytics'],
  payments:['Payment Requests','Review withdrawals across the hierarchy'],
  'smpp-dashboard':['SMPP Dashboard','Server performance and inbound SMS overview'],
  'smpp-accounts':['SMPP Accounts','Supplier/client credentials for SMPP binds'],
  'smpp-sessions':['SMPP Sessions','Gateway session telemetry'],
  'connected-clients':['Connected Clients','Current SMPP clients known to gateway telemetry'],
  'dlr-monitor':['DLR Monitor','Delivery receipt status from SMPP CDR'],
  'throughput-monitor':['Throughput Monitor','Inbound SMPP message rate'],
  'smpp-security':['SMPP Security Center','SMPP credential and access controls'],
  'connection-logs':['Connection Logs','Recent SMPP gateway events'],
  http:['HTTP Provider','HTTP/SMS provider connection and field setup'],
  api:['API Tokens','External application API access'],
  webhook:['Webhook Config','Automatic event delivery to external systems'],
  endpoint:['API Playground','Test Gateway API requests from Admin'],
  agentnews:['News for Agents','Publish announcements to Agent dashboards'],
  settings:['System Settings','Global operational controls'],
  activity:['Activity Log','Latest system activity']
};

function esc(v){return String(v??'').replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));}
function badge(v){const x=String(v||'').toLowerCase().replace(/[^a-z0-9_-]/g,'');return `<span class="badge ${esc(x)}">${esc(v||'-')}</span>`;}
function money(v){const n=Number(v||0);return Number.isFinite(n)?n.toFixed(4):'0.0000';}
function dt(v){if(!v)return '—';return esc(String(v).replace('T',' ').slice(0,19));}
function toast(msg,error=false){const el=$('#toast');el.textContent=msg;el.className='toast show'+(error?' error':'');clearTimeout(toast.t);toast.t=setTimeout(()=>el.className='toast',3600);}
async function req(action,opt={}){
  const method=opt.method||'GET';
  let url=api+'?action='+encodeURIComponent(action);
  if(opt.params)url+='&'+new URLSearchParams(opt.params).toString();
  const init={method,credentials:'include',cache:'no-store',headers:{'Accept':'application/json'}};
  if(opt.body){init.headers['Content-Type']='application/json';init.body=JSON.stringify(opt.body);}
  const r=await fetch(url,init);let data={};try{data=await r.json();}catch(e){}
  if(!r.ok){
    if((r.status===401||r.status===403)&&String(data.error||'').toLowerCase().includes('admin')){
      location.replace('/adminlogin');
    }
    throw new Error(data.error||`Request failed (${r.status})`);
  }
  return data;
}
async function reqForm(action,formData){
  const r=await fetch(api+'?action='+encodeURIComponent(action),{method:'POST',credentials:'include',cache:'no-store',headers:{'Accept':'application/json'},body:formData});
  let data={};try{data=await r.json();}catch(e){}
  if(!r.ok)throw new Error(data.error||`Request failed (${r.status})`);
  return data;
}

async function verifySession(){
  const r=await fetch('/api/session.php',{credentials:'include',cache:'no-store'});
  if(!r.ok){location.replace('/ints/login');return false;}
  const d=await r.json();adminUser=d.user;
  if(!adminUser||adminUser.role!=='admin'){location.replace(d.dashboard_url||'/ints/login');return false;}
  $('#adminName').textContent=adminUser.username||'Admin';
  $('.avatar').textContent=(adminUser.username||'A').slice(0,1).toUpperCase();
  return true;
}
function show(view){
  $$('.view').forEach(x=>x.classList.remove('active'));
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.view===view));
  const el=$('#view-'+view);if(el)el.classList.add('active');
  const t=titles[view]||[view,''];$('#pageTitle').textContent=t[0];$('#pageSubtitle').textContent=t[1];
  $('#sidebar').classList.remove('open');
  loadView(view);location.hash=view;
}
async function loadView(view){
  try{
    if(view==='dashboard')await loadDashboard();
    else if(['managers','agents','clients'].includes(view))await loadUsers(view.slice(0,-1));
    else if(view==='test')await loadUsers('test');
    else if(view==='ranges')await loadRanges();
    else if(view==='numbers')await loadNumbers();
    else if(view==='reports')await loadReports();
    else if(view==='payments')await loadPayments();
    else if(view==='smpp-dashboard')await loadSmppControl();
    else if(view==='smpp-accounts')await loadSmppAccounts();
    else if(view==='smpp-sessions')await loadSmppSessions();
    else if(view==='connected-clients')await loadSmppClients();
    else if(view==='dlr-monitor')await loadSmppDlr();
    else if(view==='throughput-monitor')await loadSmppThroughput();
    else if(view==='smpp-security')await loadSmppSecurity();
    else if(view==='connection-logs')await loadSmppLogs();
    else if(view==='http')await loadIntegrationSettings('http');
    else if(view==='api')await loadIntegrationSettings('api');
    else if(view==='webhook')await loadIntegrationSettings('webhook');
    else if(view==='endpoint')await loadIntegrationSettings('endpoint');
    else if(view==='agentnews')await loadAgentNews();
    else if(view==='settings')await loadSettings();
    else if(view==='activity')await loadActivity();
  }catch(e){toast(e.message,true);}
}

async function loadDashboard(){
  const state=$('#dashboardRefreshState');
  if(state)state.textContent='Refreshing…';

  const setCounts=(c={})=>{
    $('#sNumbers').textContent=c.numbers??0;
    $('#sAgents').textContent=c.agent??0;
    $('#sManagers').textContent=c.manager??0;
    $('#sClients').textContent=c.client??0;
    $('#sRanges').textContent=c.ranges??0;
    $('#sOtp').textContent=c.otp_total??0;
    $('#sOtpToday').textContent='Today '+(c.otp_today??0);
    $('#sSmsToday').textContent=c.sms_today??0;
    $('#sSmsTotal').textContent='Total '+(c.sms_total??0);
    $('#sPayments').textContent=c.pending_payments??0;
    if($('#sAgentsMeta'))$('#sAgentsMeta').textContent=`${c.active_agent??0} active`;
    if($('#sManagersMeta'))$('#sManagersMeta').textContent=`${c.active_manager??0} active`;
    if($('#sClientsMeta'))$('#sClientsMeta').textContent=`${c.active_client??0} active`;
  };

  try{
    const d=await req('summary');
    setCounts(d.counts||{});
    $('#topManagersBody').innerHTML=(d.top_managers||[]).map(x=>`<tr><td><b>${esc(x.username)}</b></td><td>${esc(x.agent_count)}</td><td>${esc(x.range_count)}</td><td>${esc(x.number_count)}</td><td>${esc(x.sms_30d)}</td><td>${badge(x.status)}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">No managers yet</td></tr>';
    $('#recentSms').innerHTML=(d.recent_sms||[]).map(x=>`<div class="event"><div class="event-icon">${Number(x.otp_detected)?'◉':'✉'}</div><div><strong>${esc(x.number)} · ${esc(x.manager_name||'-')}</strong><small>${esc(x.agent_name||'-')} / ${esc(x.client_name||'-')} · ${Number(x.otp_detected)?'OTP event detected':'SMS event'}</small></div><span class="event-time">${dt(x.date_time)}</span></div>`).join('')||'<div class="empty">No SMS events</div>';
    if(state)state.textContent=d.degraded?'Core totals loaded · optional stats need setup':'Live';
  }catch(err){
    // Compatibility fallback: even if a legacy SMS/CDR query fails, the Admin
    // must still show the exact Manager / Agent / Client totals.
    const results=await Promise.allSettled([
      req('users',{params:{role:'manager',limit:1}}),
      req('users',{params:{role:'agent',limit:1}}),
      req('users',{params:{role:'client',limit:1}}),
      req('numbers',{params:{limit:1}}),
      req('ranges',{params:{limit:1}}),
      req('payments',{params:{status:'pending',limit:1}})
    ]);
    const val=i=>results[i].status==='fulfilled'?results[i].value:null;
    setCounts({
      manager:val(0)?.total??0,
      agent:val(1)?.total??0,
      client:val(2)?.total??0,
      numbers:val(3)?.total??0,
      ranges:val(4)?.total??0,
      pending_payments:val(5)?.total??0,
      sms_total:0,sms_today:0,otp_total:0,otp_today:0
    });
    $('#topManagersBody').innerHTML='<tr><td colspan="6" class="empty">Account totals loaded. Run setup.php to repair optional dashboard statistics.</td></tr>';
    $('#recentSms').innerHTML='<div class="empty">SMS event feed temporarily unavailable</div>';
    if(state)state.textContent='Compatibility mode';
    toast('Account totals loaded; some optional dashboard statistics need database setup.',true);
  }
}
async function loadUsers(role){
  const m=roleMeta[role],search=$(m.search)?.value||'',status=$(m.status)?.value||'';
  const d=await req('users',{params:{role,status,search,limit:500}}),body=$(m.body);
  body.innerHTML=(d.data||[]).map(x=>userRow(role,x)).join('')||`<tr><td colspan="8" class="empty">No ${esc(role)} accounts</td></tr>`;
  const totalEl=$('#'+role+'Total');if(totalEl)totalEl.textContent=(d.total??0)+' total';
  if(role==='manager')fillManagerSelects(d.data||[]);
  if(role==='agent'){globalAgentRows=d.data||[];fillAgentSelect(globalAgentRows);}
}

const COUNTRY_NAMES=["Afghanistan", "Albania", "Algeria", "American Samoa", "Andorra", "Angola", "Anguilla", "Antarctica", "Antigua and Barbuda", "Argentina", "Armenia", "Aruba", "Australia", "Austria", "Azerbaijan", "Bahamas", "Bahrain", "Bangladesh", "Barbados", "Belarus", "Belgium", "Belize", "Benin", "Bermuda", "Bhutan", "Bolivia", "Bonaire, Sint Eustatius and Saba", "Bosnia and Herzegovina", "Botswana", "Bouvet Island", "Brazil", "British Indian Ocean Territory", "Brunei", "Bulgaria", "Burkina Faso", "Burundi", "Cabo Verde", "Cambodia", "Cameroon", "Canada", "Cayman Islands", "Central African Republic", "Chad", "Chile", "China", "Christmas Island", "Cocos (Keeling) Islands", "Colombia", "Comoros", "Congo (DRC)", "Congo (Republic)", "Cook Islands", "Costa Rica", "Croatia", "Cuba", "Curaçao", "Cyprus", "Czechia", "Côte d’Ivoire", "Denmark", "Djibouti", "Dominica", "Dominican Republic", "Ecuador", "Egypt", "El Salvador", "Equatorial Guinea", "Eritrea", "Estonia", "Eswatini", "Ethiopia", "Falkland Islands (Malvinas)", "Faroe Islands", "Fiji", "Finland", "France", "French Guiana", "French Polynesia", "French Southern Territories", "Gabon", "Gambia", "Georgia", "Germany", "Ghana", "Gibraltar", "Greece", "Greenland", "Grenada", "Guadeloupe", "Guam", "Guatemala", "Guernsey", "Guinea", "Guinea-Bissau", "Guyana", "Haiti", "Heard Island and McDonald Islands", "Holy See (Vatican City State)", "Honduras", "Hong Kong", "Hungary", "Iceland", "India", "Indonesia", "Iran", "Iraq", "Ireland", "Isle of Man", "Israel", "Italy", "Jamaica", "Japan", "Jersey", "Jordan", "Kazakhstan", "Kenya", "Kiribati", "Kuwait", "Kyrgyzstan", "Laos", "Latvia", "Lebanon", "Lesotho", "Liberia", "Libya", "Liechtenstein", "Lithuania", "Luxembourg", "Macao", "Madagascar", "Malawi", "Malaysia", "Maldives", "Mali", "Malta", "Marshall Islands", "Martinique", "Mauritania", "Mauritius", "Mayotte", "Mexico", "Micronesia, Federated States of", "Moldova", "Monaco", "Mongolia", "Montenegro", "Montserrat", "Morocco", "Mozambique", "Myanmar", "Namibia", "Nauru", "Nepal", "Netherlands", "New Caledonia", "New Zealand", "Nicaragua", "Niger", "Nigeria", "Niue", "Norfolk Island", "North Korea", "North Macedonia", "Northern Mariana Islands", "Norway", "Oman", "Pakistan", "Palau", "Palestine", "Panama", "Papua New Guinea", "Paraguay", "Peru", "Philippines", "Pitcairn", "Poland", "Portugal", "Puerto Rico", "Qatar", "Romania", "Russia", "Rwanda", "Réunion", "Saint Barthélemy", "Saint Helena, Ascension and Tristan da Cunha", "Saint Kitts and Nevis", "Saint Lucia", "Saint Martin (French part)", "Saint Pierre and Miquelon", "Saint Vincent and the Grenadines", "Samoa", "San Marino", "Sao Tome and Principe", "Saudi Arabia", "Senegal", "Serbia", "Seychelles", "Sierra Leone", "Singapore", "Sint Maarten (Dutch part)", "Slovakia", "Slovenia", "Solomon Islands", "Somalia", "South Africa", "South Georgia and the South Sandwich Islands", "South Korea", "South Sudan", "Spain", "Sri Lanka", "Sudan", "Suriname", "Svalbard and Jan Mayen", "Sweden", "Switzerland", "Syria", "Taiwan", "Tajikistan", "Tanzania", "Thailand", "Timor-Leste", "Togo", "Tokelau", "Tonga", "Trinidad and Tobago", "Tunisia", "Turkey", "Turkmenistan", "Turks and Caicos Islands", "Tuvalu", "Uganda", "Ukraine", "United Arab Emirates", "United Kingdom", "United States", "United States Minor Outlying Islands", "Uruguay", "Uzbekistan", "Vanuatu", "Venezuela", "Vietnam", "Virgin Islands, British", "Virgin Islands, U.S.", "Wallis and Futuna", "Western Sahara", "Yemen", "Zambia", "Zimbabwe", "Åland Islands"];
function populateCountrySelect(){const e=$('#countrySelect');if(!e)return;const keep=e.value;e.innerHTML='<option value="">Select Country</option>'+COUNTRY_NAMES.map(c=>`<option value="${esc(c)}">${esc(c)}</option>`).join('');if(keep&&Array.from(e.options).some(o=>o.value===keep))e.value=keep;}
function userRow(role,x){
  const contact=[x.email,x.phone,x.skype_id?('Skype: '+x.skype_id):''].filter(Boolean).map(esc).join('<br>')||'—',balances=esc(x.balances||'—'),parent=esc(x.parent_username||'—');let cells='';
  const profileName=`${esc(x.full_name||'—')}${x.company?'<br><small>'+esc(x.company)+'</small>':''}${x.country?'<br><small>'+esc(x.country)+'</small>':''}`;
  if(role==='manager')cells=`<td><b>${esc(x.username)}</b></td><td>${profileName}</td><td>${contact}</td><td>${esc(x.child_count||0)}</td><td>${balances}</td><td>${badge(x.status)}</td><td>${dt(x.last_login)}</td>`;
  if(role==='agent')cells=`<td><b>${esc(x.username)}</b></td><td>${profileName}</td><td>${parent}</td><td>${esc(x.child_count||0)}</td><td>${esc(x.direct_number_count||0)}</td><td>${badge(x.status)}</td><td>${dt(x.last_login)}</td>`;
  if(role==='client')cells=`<td><b>${esc(x.username)}</b></td><td>${esc(x.full_name||'—')}</td><td>${parent}</td><td>${esc(x.direct_number_count||0)}</td><td>${balances}</td><td>${badge(x.status)}</td><td>${dt(x.last_login)}</td>`;
  if(role==='test')cells=`<td><b>${esc(x.username)}</b></td><td>${esc(x.full_name||'—')}</td><td>${parent}</td><td>${contact}</td><td><span class="count-pill">test</span></td><td>${badge(x.status)}</td><td>${dt(x.last_login)}</td>`;
  const next=x.status==='active'?'suspended':'active';
  return `<tr>${cells}<td><div class="action-row"><button class="mini-btn ${next==='active'?'ok':'warn'}" data-user-status="${x.id}" data-next="${next}" data-role="${role}">${next==='active'?'Activate':'Suspend'}</button><button class="mini-btn danger" data-user-delete="${x.id}" data-role="${role}">Delete</button></div></td></tr>`;
}
function fillManagerSelects(rows){
  const opts='<option value="">All managers</option>'+rows.filter(x=>x.status==='active').map(x=>`<option value="${x.id}">${esc(x.username)}</option>`).join('');
  ['#numberManager','#reportManager'].forEach(s=>{
    const e=$(s);if(!e)return;const keep=e.value;e.innerHTML=opts;
    if(keep&&Array.from(e.options).some(o=>o.value===String(keep)))e.value=keep;
  });
}
function fillAgentSelect(rows){
  const e=$('#reportAgent');if(!e)return;const keep=e.value,managerId=$('#reportManager')?.value||'';
  const filtered=(rows||[]).filter(x=>x.status==='active'&&(!managerId||String(x.parent_id)===String(managerId)));
  e.innerHTML='<option value="">All agents</option>'+filtered.map(x=>`<option value="${x.id}">${esc(x.username)}</option>`).join('');
  if(keep&&Array.from(e.options).some(o=>o.value===String(keep)))e.value=keep;
}
async function ensureParents(role){const wrap=$('#parentWrap'),sel=$('#parentSelect');if(role==='manager'||role==='test'){wrap.style.display='none';sel.innerHTML='';return;}wrap.style.display='grid';const parentRole=role==='agent'?'manager':'agent';const d=await req('users',{params:{role:parentRole,status:'active',limit:500}});wrap.firstChild.nodeValue=(role==='agent'?'Manager':'Agent');sel.innerHTML='<option value="">Select '+(role==='agent'?'Manager':'Agent')+'</option>'+(d.data||[]).map(x=>`<option value="${x.id}">${esc(x.username)}${x.parent_username?' · '+esc(x.parent_username):''}</option>`).join('');}
async function openCreate(role){$('#createUserForm').reset();populateCountrySelect();$('#createRole').value=role;$('#modalTitle').textContent='Create '+role.charAt(0).toUpperCase()+role.slice(1);$('#modalHint').textContent=role==='manager'?'Manager will be controlled from this Admin panel.':role==='agent'?'Choose the Manager that owns this Agent.':role==='client'?'Choose the Agent that owns this Client.':'Separate Test account controlled directly by Admin.';await ensureParents(role);$('#userModal').hidden=false;}
function closeCreate(){$('#userModal').hidden=true;}

async function ensureRangeManagers(){return true;}
function clearRangeForm(){
  const f=$('#rangeForm');if(!f)return;f.reset();$('#rangeId').value='0';$('#rangeCurrency').value='USD';$('#rangeStatus').value='active';$('#rangeRequestEnabled').value='1';$('#rangeMaxRequests').value='';$('#rangeP11Enabled').checked=true;$('#rangeP71Enabled').checked=true;$('#rangeP77Enabled').checked=true;$('#rangeP3045Enabled').checked=true;$('#rangeFormTitle').textContent='Create Global SMS Range';$('#rangeNumbersFile').required=true;
}
function editRange(id){
  const x=rangeRows.find(v=>Number(v.id)===Number(id));if(!x)return;
  $('#rangeId').value=x.id;$('#rangeName').value=x.range_name||'';$('#rangePrefix').value=x.prefix||'';$('#rangeCurrency').value=x.currency||'USD';$('#rangeStatus').value=x.status||'active';$('#rangeRequestEnabled').value=String(Number(x.request_enabled??1));$('#rangeMaxRequests').value=(x.max_requests_per_agent===null||x.max_requests_per_agent===undefined||x.max_requests_per_agent==='')?'':x.max_requests_per_agent;$('#rangeTestNumber').value=x.test_number||'';$('#rangeP11').value=x.payout_1_1??'';$('#rangeP71').value=x.payout_7_1??'';$('#rangeP77').value=x.payout_7_7??'';$('#rangeP3045').value=x.payout_30_45??'';$('#rangeP11Enabled').checked=Number(x.payout_1_1_enabled??1)===1;$('#rangeP71Enabled').checked=Number(x.payout_7_1_enabled??1)===1;$('#rangeP77Enabled').checked=Number(x.payout_7_7_enabled??1)===1;$('#rangeP3045Enabled').checked=Number(x.payout_30_45_enabled??1)===1;$('#rangeMemo').value=x.memo||'';$('#rangeNumbersFile').value='';$('#rangeNumbersFile').required=false;$('#rangeFormTitle').textContent='Edit SMS Range';window.scrollTo({top:0,behavior:'smooth'});
}
async function loadRanges(){
  await ensureRangeManagers();
  const d=await req('ranges',{params:{search:$('#rangeSearch').value||'',status:$('#rangeStatusFilter').value||'',limit:400}});
  rangeRows=d.data||[];
  const payoutCell=(val,enabledFlag)=>{if(val===null||val===''||val===undefined)return'—';const off=Number(enabledFlag??1)!==1;return money(val)+(off?' '+badge('off'):'');};
  $('#rangesBody').innerHTML=rangeRows.map(x=>`<tr><td><b>${esc(x.range_name)}</b></td><td>${esc(x.prefix)}</td><td>${esc(x.actual_total??x.total_numbers??0)}</td><td>${esc(x.actual_available??x.available_numbers??0)}</td><td>${esc(x.test_number||'—')}</td><td>${esc(x.currency)}</td><td>${payoutCell(x.payout_1_1,x.payout_1_1_enabled)}</td><td>${payoutCell(x.payout_7_1,x.payout_7_1_enabled)}</td><td>${payoutCell(x.payout_7_7,x.payout_7_7_enabled)}</td><td>${payoutCell(x.payout_30_45,x.payout_30_45_enabled)}</td><td>${Number(x.request_enabled??1)?badge('enabled'):badge('disabled')}</td><td>${(x.max_requests_per_agent===null||x.max_requests_per_agent===undefined||Number(x.max_requests_per_agent)<=0)?'Unlimited':esc(x.max_requests_per_agent)+'/agent'}</td><td>${badge(x.status)}</td><td><div class="action-row"><button class="mini-btn" data-range-edit="${x.id}">Edit</button>${Number(x.assigned_numbers||0)>0?`<button class="mini-btn warn" data-range-return="${x.id}">Return All</button>`:''}<button class="mini-btn danger" data-range-delete="${x.id}" data-range-assigned="${x.assigned_numbers||0}">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="14" class="empty">No SMS ranges found</td></tr>';
  fillReturnRangeSelect(rangeRows);
}
function fillReturnRangeSelect(rows){
  const e=$('#returnRangeSelect');if(!e)return;const keep=e.value;
  e.innerHTML='<option value="">Select a range to return all its numbers…</option>'+(rows||[]).map(x=>`<option value="${x.id}">${esc(x.range_name)} · ${esc(x.prefix)} (${x.assigned_numbers||0} assigned)</option>`).join('');
  if(keep&&Array.from(e.options).some(o=>o.value===String(keep)))e.value=keep;
}
async function returnRangeNumbers(id){
  if(!id){toast('Select a range first',true);return;}
  const row=(rangeRows||[]).find(x=>String(x.id)===String(id));
  const assigned=row?Number(row.assigned_numbers||0):null;
  if(assigned===0){toast('No assigned numbers in this range.',true);return;}
  if(!confirm(`Return all assigned numbers in "${row?row.range_name:'this range'}" to the available pool? They will be removed from every Agent's/Manager's number list.`))return;
  const d=await req('range-return-numbers',{method:'POST',body:{range_id:Number(id)}});
  toast(d.message||'Numbers returned');
  await Promise.all([loadRanges(),loadNumbers().catch(()=>{}),loadDashboard()]);
}
async function saveRange(){
  const f=$('#rangeForm'),fd=new FormData(f),id=Number($('#rangeId').value||0),file=$('#rangeNumbersFile').files?.[0];
  if(!id&&!file)throw new Error('Upload a TXT or CSV numbers file for a new range');
  // Checkboxes are omitted from FormData when unchecked, so set each toggle explicitly.
  fd.set('payout_1_1_enabled',$('#rangeP11Enabled').checked?'1':'0');
  fd.set('payout_7_1_enabled',$('#rangeP71Enabled').checked?'1':'0');
  fd.set('payout_7_7_enabled',$('#rangeP77Enabled').checked?'1':'0');
  fd.set('payout_30_45_enabled',$('#rangeP3045Enabled').checked?'1':'0');
  fd.set('max_requests_per_agent',($('#rangeMaxRequests').value||'').replace(/[^0-9]/g,''));
  const d=await reqForm('range-save',fd);toast(`${d.message||'Range saved'}${Number(d.inserted||0)?' · '+d.inserted+' number(s) imported':''}${Number(d.duplicates||0)?' · '+d.duplicates+' duplicate(s) skipped':''}`);clearRangeForm();await Promise.all([loadRanges(),loadDashboard()]);
}
async function deleteRange(id,assigned){
  if(Number(assigned)>0){toast('Unassign all numbers from this range before deleting it.',true);return;}
  if(!confirm('Delete this SMS range and its unassigned number inventory?'))return;
  const d=await req('range-delete',{method:'POST',body:{id:Number(id)}});toast(d.message||'Range deleted');if(Number($('#rangeId').value)===Number(id))clearRangeForm();await Promise.all([loadRanges(),loadDashboard()]);
}

async function loadNumbers(){await ensureGlobalDropdowns();const d=await req('numbers',{params:{search:$('#numberSearch').value||'',manager_id:$('#numberManager').value||'',status:$('#numberStatus').value||'',limit:300}});$('#numbersTotal').textContent=(d.total||0)+' records';$('#numbersBody').innerHTML=(d.data||[]).map(x=>`<tr><td><b>${esc(x.number)}</b>${Number(x.is_test)?' '+badge('test'):''}</td><td>${esc(x.range_name)}</td><td>${esc(x.prefix)}</td><td>${esc(x.manager_name||'—')}</td><td>${esc(x.assigned_username||'—')}</td><td>${esc(x.assigned_role||'—')}</td><td>${esc(x.pay_term||'—')}</td><td>${money(x.payout_rate)} ${esc(x.currency)}</td><td>${badge(x.status)}</td><td>${x.status==='assigned'?`<button class="mini-btn warn" data-number-unassign="${x.id}">Unassign</button>`:'—'}</td></tr>`).join('')||'<tr><td colspan="10" class="empty">No numbers found</td></tr>';}
async function unassignNumber(id){if(!confirm('Return this number to the available pool? It will be removed from the agent\'s account.'))return;const d=await req('number-unassign',{method:'POST',body:{id}});toast(d.message);await Promise.all([loadNumbers(),loadDashboard()]);}
async function ensureGlobalDropdowns(){
  const [m,a]=await Promise.all([
    req('users',{params:{role:'manager',status:'active',limit:500}}),
    req('users',{params:{role:'agent',status:'active',limit:500}})
  ]);
  globalAgentRows=a.data||[];
  fillManagerSelects(m.data||[]);
  fillAgentSelect(globalAgentRows);
}
function localToSql(v,end=false){if(!v)return '';const s=v.replace('T',' ');return s.length===16?s+':'+(end?'59':'00'):s;}
async function loadReports(){await ensureGlobalDropdowns();const d=await req('reports',{params:{search:$('#reportSearch').value||'',from:localToSql($('#reportFrom').value),to:localToSql($('#reportTo').value,true),manager_id:$('#reportManager').value||'',agent_id:$('#reportAgent').value||'',otp_only:$('#reportOtpOnly').checked?1:0,limit:300}});$('#rSms').textContent=d.summary?.sms??0;$('#rOtp').textContent=d.summary?.otp??0;$('#rProfit').textContent=money(d.summary?.profit||0);$('#reportsBody').innerHTML=(d.data||[]).map(x=>`<tr><td>${dt(x.date_time)}</td><td>${esc(x.manager_name||'—')}</td><td>${esc(x.agent_name||'—')}</td><td>${esc(x.client_name||'—')}</td><td>${esc(x.range_name||'—')}</td><td><b>${esc(x.number)}</b></td><td>${esc(x.cli||'—')}</td><td>${esc(x.sms_count)}</td><td>${Number(x.otp_detected)?badge('OTP'):'—'}</td><td>${esc(x.currency)}</td><td>${badge(x.smpp_status||'delivered')}</td></tr>`).join('')||'<tr><td colspan="11" class="empty">No report rows</td></tr>';}
async function loadPayments(){const d=await req('payments',{params:{status:$('#paymentStatus').value||'',limit:300}});$('#paymentsTotal').textContent=(d.total||0)+' records';$('#paymentsBody').innerHTML=(d.data||[]).map(x=>`<tr><td>${dt(x.created_at)}</td><td><b>${esc(x.username)}</b></td><td>${esc(x.role)}</td><td>${esc(x.parent_username||'—')}</td><td>${money(x.amount)} ${esc(x.currency)}</td><td>${esc(x.method||'—')}</td><td>${badge(x.status)}</td><td><div class="action-row">${x.status==='pending'?`<button class="mini-btn ok" data-payment="${x.id}" data-pay-status="approved">Approve</button><button class="mini-btn danger" data-payment="${x.id}" data-pay-status="rejected">Reject</button>`:''}${x.status==='approved'?`<button class="mini-btn ok" data-payment="${x.id}" data-pay-status="completed">Complete</button>`:''}</div></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No payment requests</td></tr>';}


function smppStatusText(x){return String(x||'unknown').replace(/_/g,' ');}
function smppTableEmpty(cols,msg='No data'){return `<tr><td colspan="${cols}" class="empty">${esc(msg)}</td></tr>`;}

async function loadSmppControl(){
  const d=await req('smpp-control');
  $('#smppJasminStatus').textContent=d.jasmin_running?'Running':'Stopped / Unknown';
  $('#smppJasminMeta').textContent=d.jasmin_running?'Gateway process detected':'Process not detected';
  const a=d.active_config||null;
  $('#smppActiveName').textContent=a?.config_name||'None';
  $('#smppConfigStatus').textContent=a?.status||'No active configuration';
  $('#smpp24h').textContent=d.stats?.daily??0;
  $('#smpp1h').textContent=d.stats?.hourly??0;
  $('#smppEndpoint').textContent=a?`${a.inbound_host}:${a.inbound_port}`:'—';
  $('#smppCallback').textContent=location.origin+'/api/smpp.php?action=receive';
  if(a) editSmpp(a.id); else clearSmppForm();
}
async function loadSmppAccounts(){
  const d=await req('smpp-accounts');
  const rows=d.accounts||[];
  $('#smppAccountTotal').textContent=rows.length+' total';
  $('#smppAccountsBody').innerHTML=rows.map(x=>`<tr>
    <td><b>${esc(x.username)}</b></td><td>${esc(x.supplier_name||'—')}</td>
    <td>${badge(x.bind_type)}</td><td>${esc(x.max_connections)}</td>
    <td>${esc(x.allowed_ranges||'*')}</td><td>${badge(x.status)}</td>
    <td>${dt(x.last_connected_at)}</td>
    <td><button class="mini-btn" data-smpp-account-edit="${x.id}">Edit</button></td>
  </tr>`).join('')||smppTableEmpty(8);
  window._smppAccounts=rows;
}
function editSmppAccount(id){
  const x=(window._smppAccounts||[]).find(v=>Number(v.id)===Number(id)); if(!x)return;
  const f=$('#smppAccountForm'); f.elements.id.value=x.id; f.elements.username.value=x.username||'';
  f.elements.supplier_name.value=x.supplier_name||''; f.elements.supplier_contact.value=x.supplier_contact||'';
  f.elements.bind_type.value=x.bind_type||'TR'; f.elements.max_connections.value=x.max_connections||10;
  f.elements.status.value=x.status||'active'; f.elements.allowed_ranges.value=x.allowed_ranges||''; f.elements.password_hash.value='';
}
function clearSmppAccountForm(){const f=$('#smppAccountForm');if(!f)return;f.reset();f.elements.id.value='0';f.elements.max_connections.value='10';f.elements.bind_type.value='TR';f.elements.status.value='active';}
async function saveSmppAccount(){
  const f=$('#smppAccountForm'), body={};
  Array.from(f.elements).forEach(e=>{if(e.name)body[e.name]=e.value;});
  const d=await req('smpp-account-save',{method:'POST',body}); toast(d.message||'SMPP account saved','success'); clearSmppAccountForm(); await loadSmppAccounts();
}
async function loadSmppSessions(){
  const d=await req('smpp-sessions'); const rows=d.sessions||[];
  $('#smppSessionsBody').innerHTML=rows.map(x=>`<tr><td class="monospace">${esc(x.username||x.system_id||'—')}</td><td>${esc(x.ip||'—')}</td><td>${badge(x.bind_type||'TR')}</td><td>${esc(x.messages||0)}</td><td>${dt(x.last_connected_at)}</td><td>${badge(x.status||'unknown')}</td></tr>`).join('')||smppTableEmpty(6,'No live session telemetry is available.');
}
async function loadSmppClients(){
  const d=await req('smpp-sessions'); const rows=d.sessions||[];
  $('#smppClientsBody').innerHTML=rows.map(x=>`<tr><td><b>${esc(x.username||'—')}</b></td><td>${esc(x.supplier_name||'—')}</td><td>${badge(x.bind_type||'TR')}</td><td>${dt(x.last_connected_at)}</td><td>${badge(x.status||'unknown')}</td></tr>`).join('')||smppTableEmpty(5,'No connected-client telemetry is available.');
}
async function loadSmppDlr(){
  const d=await req('smpp-dlr'); $('#dlrDelivered').textContent=d.delivered||0; $('#dlrPending').textContent=d.pending||0; $('#dlrFailed').textContent=d.failed||0; $('#dlrRate').textContent=(d.dlr_rate||0)+'%';
  $('#dlrBody').innerHTML=(d.rows||[]).map(x=>`<tr><td class="monospace">${esc(x.message_id)}</td><td>${esc(x.source_addr)}</td><td>${esc(x.destination_addr)}</td><td>${badge(x.message_status)}</td><td>${dt(x.submit_date)}</td><td>${esc(x.connector_id||'—')}</td></tr>`).join('')||smppTableEmpty(6);
}
async function loadSmppThroughput(){
  const d=await req('smpp-throughput'); $('#tpCurrent').textContent=d.current_mps||0; $('#tpPeak').textContent=d.peak_mps||0; $('#tpTotal').textContent=d.total_24h||0;
  $('#tpBody').innerHTML=(d.rows||[]).map(x=>`<tr><td>${dt(x.minute)}</td><td>${esc(x.messages)}</td><td>${esc(x.mps)}</td></tr>`).join('')||smppTableEmpty(3);
}
async function loadSmppSecurity(){
  const d=await req('smpp-security');
  $('#smppSecurityBody').innerHTML=(d.events||[]).map(x=>`<tr><td>${dt(x.time)}</td><td>${esc(x.event)}</td><td>${esc(x.details)}</td></tr>`).join('')||smppTableEmpty(3);
}
async function loadSmppLogs(){
  const d=await req('smpp-logs');
  $('#smppLogsBody').innerHTML=(d.rows||[]).map(x=>`<tr><td>${dt(x.time)}</td><td>${esc(x.event)}</td><td>${esc(x.account||'—')}</td><td>${esc(x.ip||'—')}</td><td>${badge(x.status||'info')}</td></tr>`).join('')||smppTableEmpty(5);
}

function clearSmppForm(){const f=$('#smppForm');f.reset();$('#smppId').value='0';$('#smppPort').value='2775';$('#smppHost').value='0.0.0.0';$('#smppStatus').value='active';$('#smppPassword').required=true;}
function editSmpp(id){const x=smppProfiles.find(v=>Number(v.id)===Number(id));if(!x)return;$('#smppId').value=x.id;$('#smppConfigName').value=x.config_name||'';$('#smppHost').value=x.inbound_host||'0.0.0.0';$('#smppPort').value=x.inbound_port||2775;$('#smppSystemId').value=x.inbound_system_id||'';$('#smppStatus').value=x.status||'inactive';$('#smppPassword').value='';$('#smppPassword').required=false;window.scrollTo({top:0,behavior:'smooth'});}
async function loadSmpp(){
  const callbackUrl=location.origin+'/api/smpp.php?action=receive';
  $('#smppWebhookUrl').textContent=callbackUrl;
  $('#jasminPanelUrl').textContent=location.origin;
  $('#jasminCallbackUrl').textContent=callbackUrl;
  const d=await req('smpp-config');
  $('#jasminApiPort').textContent=d.connection_info?.api_port||'1401';
  if(!d.installed){smppProfiles=[];$('#smppJasmin').textContent='Not Ready';$('#smppActiveConfig').textContent='Migration Required';$('#smppDaily').textContent='0';$('#smppTotal').textContent='0';$('#smppConfigCount').textContent='0 profiles';$('#smppConfigsBody').innerHTML='<tr><td colspan="8" class="empty">Run database/migrations/admin_smpp_news_upgrade.sql first.</td></tr>';return;}
  smppProfiles=d.configs||[];const active=d.active_config||null;
  $('#smppJasmin').textContent=d.jasmin_running?'Running':'Stopped / Unknown';$('#smppActiveConfig').textContent=active?.config_name||'None';$('#smppDaily').textContent=d.stats?.daily??0;$('#smppTotal').textContent=active?.total_received??0;$('#smppConfigCount').textContent=smppProfiles.length+' profiles';
  $('#smppConfigsBody').innerHTML=smppProfiles.map(x=>`<tr><td><b>${esc(x.config_name)}</b></td><td>${esc(x.inbound_host)}</td><td>${esc(x.inbound_port)}</td><td>${esc(x.inbound_system_id)}</td><td>${badge(x.status)}</td><td>${esc(x.total_received||0)}</td><td>${dt(x.last_received_at)}</td><td><button class="mini-btn" data-smpp-edit="${x.id}">Edit</button></td></tr>`).join('')||'<tr><td colspan="8" class="empty">No SMPP profile configured</td></tr>';
  if(Number($('#smppId').value||0)===0){if(active)editSmpp(active.id);else if(smppProfiles.length)editSmpp(smppProfiles[0].id);}
}
async function saveSmpp(){
  const f=$('#smppForm'),body={id:Number(f.elements.id.value||0),config_name:f.elements.config_name.value,inbound_host:f.elements.inbound_host.value,inbound_port:Number(f.elements.inbound_port.value||0),inbound_system_id:f.elements.inbound_system_id.value,inbound_password:f.elements.inbound_password.value,status:f.elements.status.value};
  const d=await req('smpp-config',{method:'POST',body});toast(d.message||'SMPP config saved');$('#smppPassword').value='';$('#smppPassword').required=false;await loadSmpp();
}


function integrationDefaults(type){
  if(type==='http')return {provider_name:'',status:'active',url:'',method:'POST',api_key:'',sender_id:'',timeout:'15',notes:''};
  if(type==='api')return {status:'active',version:'v1',base_url:location.origin+'/api',rate_limit:'60',scopes:'numbers,sms,users,stats'};
  return {url:'',method:'POST',secret:'',timeout:'10',retries:'3',events:'otp_received,number_allocated,user_created'};
}
function fillIntegrationForm(type,data){
  const f=$(type==='http'?'#httpProviderForm':type==='api'?'#apiConfigForm':'#webhookForm'); if(!f)return;
  const d=Object.assign(integrationDefaults(type),data||{});
  Object.keys(d).forEach(k=>{if(f.elements[k])f.elements[k].value=d[k]??'';});
}
async function loadIntegrationSettings(type){
  const d=await req('integration-settings',{params:{type}});
  fillIntegrationForm(type,d.config||{});
  if(type==='api' && $('#apiTokenOutput'))$('#apiTokenOutput').textContent='No new token generated.';
}
async function saveIntegrationSettings(type){
  const f=$(type==='http'?'#httpProviderForm':type==='api'?'#apiConfigForm':'#webhookForm');
  const body={type,config:{}};
  Array.from(f.elements).forEach(e=>{if(e.name)body.config[e.name]=e.value;});
  const d=await req('integration-settings',{method:'POST',body});toast(d.message||'Configuration saved');await loadIntegrationSettings(type);
}
async function generateApiToken(){
  const d=await req('integration-token',{method:'POST',body:{name:'Admin API Token'}});
  if($('#apiTokenOutput'))$('#apiTokenOutput').textContent=d.token||'Token generated.';
  toast('API token generated');
}
async function testWebhookConfig(){
  const f=$('#webhookForm'); const url=f?.elements?.url?.value||'';
  if(!/^https?:\/\//i.test(url)){toast('Enter a valid HTTP/HTTPS webhook URL',true);return;}
  toast('Webhook configuration saved. Test delivery should be performed from the connected server.');
}
async function runApiPlayground(){
  const f=$('#apiPlaygroundForm'), out=$('#apiPlaygroundOutput'); if(!f||!out)return;
  let path=f.elements.path.value.trim(); if(!path.startsWith('/'))path='/'+path;
  if(!/^\/api\//.test(path)){out.textContent='Blocked: endpoint must be under /api/';return;}
  let body=f.elements.body.value.trim(); let opts={method:f.elements.method.value,credentials:'include',headers:{'Accept':'application/json'}};
  if(body && opts.method!=='GET'){try{JSON.parse(body);opts.headers['Content-Type']='application/json';opts.body=body;}catch(e){out.textContent='Invalid JSON request body.';return;}}
  out.textContent='Running…';
  try{const r=await fetch(path,opts);const text=await r.text();out.textContent=`HTTP ${r.status}\n\n${text}`;}catch(e){out.textContent='Request failed: '+e.message;}
}

function clearAgentNewsForm(){const f=$('#agentNewsForm');f.reset();$('#agentNewsId').value='0';$('#agentNewsStatus').value='published';$('#agentNewsFormTitle').textContent='Create Agent News';}
function editAgentNews(id){const x=agentNewsRows.find(v=>Number(v.id)===Number(id));if(!x)return;$('#agentNewsId').value=x.id;$('#agentNewsTitle').value=x.title||'';$('#agentNewsContent').value=x.content||'';$('#agentNewsStatus').value=x.status||'draft';$('#agentNewsFormTitle').textContent='Edit Agent News';window.scrollTo({top:0,behavior:'smooth'});}
async function loadAgentNews(){const d=await req('agent-news',{params:{search:$('#agentNewsSearch').value||'',status:$('#agentNewsFilterStatus').value||'',limit:300}});agentNewsRows=d.data||[];$('#agentNewsBody').innerHTML=agentNewsRows.map(x=>`<tr><td>${dt(x.published_at||x.created_at)}</td><td><b>${esc(x.title)}</b></td><td class="wrap-cell news-preview">${esc((x.content||'').slice(0,150))}</td><td>${esc(x.author_name||'—')} <small>${esc(x.author_role||'')}</small></td><td>${badge(x.status)}</td><td><div class="action-row"><button class="mini-btn" data-agent-news-edit="${x.id}">Edit</button><button class="mini-btn danger" data-agent-news-delete="${x.id}">Delete</button></div></td></tr>`).join('')||'<tr><td colspan="6" class="empty">No Agent news found</td></tr>';}
async function saveAgentNews(){const f=$('#agentNewsForm'),body={id:Number(f.elements.id.value||0),title:f.elements.title.value,content:f.elements.content.value,status:f.elements.status.value};const d=await req('agent-news-save',{method:'POST',body});toast(d.message||'News saved');clearAgentNewsForm();await loadAgentNews();}
async function deleteAgentNews(id){if(!confirm('Delete this Agent news?'))return;const d=await req('agent-news-delete',{method:'POST',body:{id:Number(id)}});toast(d.message||'News deleted');if(Number($('#agentNewsId').value)===Number(id))clearAgentNewsForm();await loadAgentNews();}

async function loadSettings(){const d=await req('settings');const f=$('#settingsForm');Object.entries(d.settings||{}).forEach(([k,o])=>{const e=f.elements[k];if(!e)return;if(e.type==='checkbox')e.checked=String(o.value)==='1';else e.value=o.value??'';});}
async function saveSettings(){const f=$('#settingsForm'),body={};['site_name','minimum_withdrawal_usd','minimum_withdrawal_eur','minimum_withdrawal_gbp','default_page_size','support_note'].forEach(k=>body[k]=f.elements[k].value);body.payment_requests_enabled=f.elements.payment_requests_enabled.checked?1:0;body.maintenance_mode=f.elements.maintenance_mode.checked?1:0;const d=await req('settings',{method:'POST',body});toast(d.message||'Settings saved');}
async function loadActivity(){const d=await req('activity',{params:{limit:200}});$('#activityBody').innerHTML=(d.data||[]).map(x=>`<tr><td>${dt(x.created_at)}</td><td>${esc(x.username||'system')}</td><td>${esc(x.role||'—')}</td><td>${esc(x.action)}</td><td class="wrap-cell">${esc(x.description||'—')}</td><td>${esc(x.ip_address||'—')}</td></tr>`).join('')||'<tr><td colspan="6" class="empty">No activity</td></tr>';}

async function userStatus(id,status,role){if(!confirm(`Set this ${role} to ${status}?`))return;const d=await req('user-status',{method:'POST',body:{id,status}});toast(d.message);await Promise.all([loadUsers(role),loadDashboard()]);}
async function userDelete(id,role){if(!confirm(`Delete this ${role}? Accounts with children/ranges/numbers cannot be deleted.`))return;const d=await req('user-delete',{method:'POST',body:{id}});toast(d.message);await Promise.all([loadUsers(role),loadDashboard()]);}
async function paymentStatus(id,status){if(!confirm(`Set payment request to ${status}?`))return;const d=await req('payment-status',{method:'POST',body:{id,status}});toast(d.message);await Promise.all([loadPayments(),loadDashboard()]);}

function bind(){
  $$('#mainNav .nav-item').forEach(b=>b.addEventListener('click',()=>show(b.dataset.view)));
  $('#menuBtn').addEventListener('click',()=>$('#sidebar').classList.toggle('open'));$('#logoutBtn').addEventListener('click',()=>location.href='/ints/logout');
  if($('#refreshDashboardBtn'))$('#refreshDashboardBtn').addEventListener('click',()=>loadDashboard().catch(e=>toast(e.message,true)));
  if($('#reportManager'))$('#reportManager').addEventListener('change',()=>fillAgentSelect(globalAgentRows));
  $$('[data-jump]').forEach(b=>b.addEventListener('click',()=>show(b.dataset.jump)));
  $$('[data-create-role]').forEach(b=>b.addEventListener('click',()=>openCreate(b.dataset.createRole).catch(e=>toast(e.message,true))));
  $('#closeModalBtn').onclick=$('#cancelModalBtn').onclick=closeCreate;$('#userModal').addEventListener('click',e=>{if(e.target===$('#userModal'))closeCreate();});
  $$('[data-load-users]').forEach(b=>b.addEventListener('click',()=>loadUsers(b.dataset.loadUsers).catch(e=>toast(e.message,true))));
  $('#rangeSearchBtn').onclick=()=>loadRanges().catch(e=>toast(e.message,true));$('#newRangeBtn').onclick=()=>{clearRangeForm();$('#rangeName').focus();};$('#clearRangeBtn').onclick=clearRangeForm;
  $('#dbUpgradeBtn').onclick=async()=>{
    const btn=$('#dbUpgradeBtn');btn.disabled=true;const orig=btn.textContent;btn.textContent='Upgrading…';
    try{const d=await req('db-upgrade',{method:'POST',body:{}});toast(d.message||'Database upgraded');}
    catch(e){toast(e.message,true);}
    finally{btn.disabled=false;btn.textContent=orig;}
  };
  $('#rangeForm').addEventListener('submit',e=>{e.preventDefault();saveRange().catch(x=>toast(x.message,true));});
  $('#numberSearchBtn').onclick=()=>loadNumbers().catch(e=>toast(e.message,true));$('#reportSearchBtn').onclick=()=>loadReports().catch(e=>toast(e.message,true));$('#paymentSearchBtn').onclick=()=>loadPayments().catch(e=>toast(e.message,true));
  if($('#httpProviderForm'))$('#httpProviderForm').addEventListener('submit',e=>{e.preventDefault();saveIntegrationSettings('http').catch(x=>toast(x.message,true));});
  if($('#apiConfigForm'))$('#apiConfigForm').addEventListener('submit',e=>{e.preventDefault();saveIntegrationSettings('api').catch(x=>toast(x.message,true));});
  if($('#webhookForm'))$('#webhookForm').addEventListener('submit',e=>{e.preventDefault();saveIntegrationSettings('webhook').catch(x=>toast(x.message,true));});
  if($('#generateApiTokenBtn'))$('#generateApiTokenBtn').onclick=()=>generateApiToken().catch(e=>toast(e.message,true));
  if($('#testWebhookBtn'))$('#testWebhookBtn').onclick=()=>testWebhookConfig().catch(e=>toast(e.message,true));
  if($('#apiPlaygroundForm'))$('#apiPlaygroundForm').addEventListener('submit',e=>{e.preventDefault();runApiPlayground().catch(x=>toast(x.message,true));});
  $('#newAgentNewsBtn').onclick=()=>{clearAgentNewsForm();$('#agentNewsTitle').focus();};$('#cancelAgentNewsEditBtn').onclick=clearAgentNewsForm;$('#agentNewsSearchBtn').onclick=()=>loadAgentNews().catch(e=>toast(e.message,true));
  $('#agentNewsForm').addEventListener('submit',e=>{e.preventDefault();saveAgentNews().catch(x=>toast(x.message,true));});
  $('#saveSettingsBtn').onclick=()=>saveSettings().catch(e=>toast(e.message,true));$('#refreshActivityBtn').onclick=()=>loadActivity().catch(e=>toast(e.message,true));
  $('#createUserForm').addEventListener('submit',async e=>{e.preventDefault();const body=Object.fromEntries(new FormData(e.currentTarget).entries());try{const d=await req('user-create',{method:'POST',body});toast(d.message);closeCreate();show(body.role+'s');}catch(err){toast(err.message,true);}});
  document.addEventListener('click',e=>{
    const s=e.target.closest('[data-user-status]');if(s)userStatus(s.dataset.userStatus,s.dataset.next,s.dataset.role).catch(x=>toast(x.message,true));
    const d=e.target.closest('[data-user-delete]');if(d)userDelete(d.dataset.userDelete,d.dataset.role).catch(x=>toast(x.message,true));
    const p=e.target.closest('[data-payment]');if(p)paymentStatus(p.dataset.payment,p.dataset.payStatus).catch(x=>toast(x.message,true));
    const se=e.target.closest('[data-smpp-edit]');if(se)editSmpp(se.dataset.smppEdit);
    const sae=e.target.closest('[data-smpp-account-edit]');if(sae)editSmppAccount(sae.dataset.smppAccountEdit);
    const ne=e.target.closest('[data-agent-news-edit]');if(ne)editAgentNews(ne.dataset.agentNewsEdit);
    const nd=e.target.closest('[data-agent-news-delete]');if(nd)deleteAgentNews(nd.dataset.agentNewsDelete).catch(x=>toast(x.message,true));
    const re=e.target.closest('[data-range-edit]');if(re)editRange(re.dataset.rangeEdit);
    const rd=e.target.closest('[data-range-delete]');if(rd)deleteRange(rd.dataset.rangeDelete,rd.dataset.rangeAssigned).catch(x=>toast(x.message,true));
    const nu=e.target.closest('[data-number-unassign]');if(nu)unassignNumber(nu.dataset.numberUnassign).catch(x=>toast(x.message,true));
    const rr=e.target.closest('[data-range-return]');if(rr)returnRangeNumbers(rr.dataset.rangeReturn).catch(x=>toast(x.message,true));
  });
  $('#returnRangeBtn').onclick=()=>returnRangeNumbers($('#returnRangeSelect').value).catch(e=>toast(e.message,true));
  const sf=$('#smppForm');if(sf)sf.onsubmit=e=>{e.preventDefault();saveSmpp().catch(x=>toast(x.message,true));};
  const saf=$('#smppAccountForm');if(saf)saf.onsubmit=e=>{e.preventDefault();saveSmppAccount().catch(x=>toast(x.message,true));};
  const nsa=$('#newSmppAccountBtn');if(nsa)nsa.onclick=clearSmppAccountForm;
  const csa=$('#clearSmppAccountBtn');if(csa)csa.onclick=clearSmppAccountForm;
  ['smppRefreshBtn','smppSessionsRefreshBtn','dlrRefreshBtn','throughputRefreshBtn','smppLogsRefreshBtn'].forEach(id=>{const b=$('#'+id);if(b)b.onclick=()=>loadView(location.hash.replace('#','')||'smpp-dashboard').catch(x=>toast(x.message,true));});
}

(async function init(){bind();clearRangeForm();if(!await verifySession())return;const h=location.hash.replace('#','');show(titles[h]?h:'dashboard');})();
})();
