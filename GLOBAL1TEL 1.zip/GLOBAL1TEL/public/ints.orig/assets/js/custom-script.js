/*==========================
TOUCHY SCROLL FOR SIDEBAR
==========================*/
$('.accordion_mnu').initMenu();
$("#sidebar").niceScroll({
    cursorcolor: "#2f2e2e",
    cursoropacitymax: 0.7,
    boxzoom: false,
    touchbehavior: true
});
$("#sidebar").mouseover(function(){
  $("#sidebar").niceScroll().resize();
});
/*==========================================================
GLOBAL1TEL — user menu opens ONLY via press-and-hold on the
username/avatar element (top-right). A normal tap/click there,
or any click/tap anywhere else in the navbar (including the
logo area), will NOT open it.
==========================================================*/
(function(){
	var $toggle = $('.navbar .nav.pull-right li.dropdown > a.dropdown-toggle');
	if(!$toggle.length){ return; }

	// Stop Bootstrap's built-in click-to-open behavior for this toggle only.
	$toggle.removeAttr('data-toggle');

	// Stop the browser's own long-press "link" menu (Open in new tab, Copy
	// link address, etc.) from popping up while the user holds this element.
	$toggle.attr('href', 'javascript:void(0)');
	$toggle.css({
		'-webkit-touch-callout': 'none',
		'-webkit-user-select': 'none',
		'user-select': 'none',
		'touch-action': 'manipulation'
	});
	$toggle.on('contextmenu', function(e){
		e.preventDefault();
		return false;
	});

	var HOLD_MS = 500;
	var pressTimer = null;
	var $menuLi = $toggle.closest('li.dropdown');

	function openMenu(){
		$('.navbar .nav.pull-right li.dropdown.open').not($menuLi).removeClass('open');
		$menuLi.addClass('open');
	}
	function closeMenu(){
		$menuLi.removeClass('open');
	}
	function cancelPress(){
		clearTimeout(pressTimer);
		pressTimer = null;
	}

	$toggle.on('mousedown touchstart', function(e){
		cancelPress();
		pressTimer = setTimeout(function(){
			openMenu();
			pressTimer = null;
		}, HOLD_MS);
	});
	$toggle.on('mouseup mouseleave touchend touchcancel', cancelPress);

	// A plain click never opens/navigates.
	$toggle.on('click', function(e){
		e.preventDefault();
		e.stopPropagation();
	});

	// Clicking/tapping anywhere outside the menu closes it.
	$(document).on('click touchstart', function(e){
		if(!$(e.target).closest('li.dropdown').length){
			closeMenu();
		}
	});
})();
