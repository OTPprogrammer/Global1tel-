(function () {
    'use strict';

    function roleFromPath() {
        var p = window.location.pathname.toLowerCase();
        if (p.indexOf('/ints/manager/') !== -1) return 'manager';
        if (p.indexOf('/ints/agent/') !== -1) return 'agent';
        if (p.indexOf('/ints/client/') !== -1) return 'client';
        if (p.indexOf('/ints/test/') !== -1) return 'test';
        return '';
    }

    function dashboardFor(role) {
        if (role === 'admin') return '/ints/admin/AdminDashboard.html';
        if (role === 'manager') return '/ints/manager/SMSDashboard.html';
        if (role === 'agent') return '/ints/agent/SMSDashboard.html';
        if (role === 'client') return '/ints/client/SMSDashboard.html';
        if (role === 'test') return '/ints/test/SMSDashboard.html';
        return '/ints/login';
    }

    function setNavUsername(username) {
        var existing = document.getElementById('nav-username');
        if (existing) {
            existing.textContent = username;
            return;
        }

        var link = document.querySelector('.top-nav .nav.pull-right a.dropdown-toggle');
        if (!link) return;

        var span = document.createElement('span');
        span.id = 'nav-username';
        span.textContent = username;

        // Remove only the old leading username text; preserve notification/user icons.
        for (var i = 0; i < link.childNodes.length; i++) {
            var n = link.childNodes[i];
            if (n.nodeType === Node.TEXT_NODE && n.nodeValue.trim()) {
                n.nodeValue = ' ';
                break;
            }
        }
        link.insertBefore(span, link.firstChild);
        link.insertBefore(document.createTextNode(' '), span.nextSibling);
    }

    function setSidebarUsername(username) {
        var existing = document.getElementById('sidebar-username');
        if (existing) {
            existing.textContent = username;
            return;
        }

        var box = document.querySelector('#sidebar .lgxx');
        if (!box) return;

        var walker = document.createTreeWalker(box, NodeFilter.SHOW_TEXT);
        var node;
        while ((node = walker.nextNode())) {
            if (/\bWelcome\s+\S+/i.test(node.nodeValue)) {
                node.nodeValue = node.nodeValue.replace(/\bWelcome\s+\S+/i, 'Welcome ' + username);
                break;
            }
        }
    }

    function updateSidebarClock() {
        var box = document.querySelector('#sidebar .lgxx');
        if (!box) return;

        var text = new Date().toLocaleString();
        var existing = document.getElementById('sidebar-datetime');
        if (existing) {
            existing.textContent = text;
            return;
        }

        var walker = document.createTreeWalker(box, NodeFilter.SHOW_TEXT);
        var node;
        while ((node = walker.nextNode())) {
            if (/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/.test(node.nodeValue)) {
                node.nodeValue = node.nodeValue.replace(/\d{4}-\d{2}-\d{2}\s+\d{2}:\d{2}:\d{2}/, text);
                return;
            }
        }
    }

    function cleanLegacyAgentOptions() {
        document.querySelectorAll('select option').forEach(function (opt) {
            if (/^ShaziPero$/i.test(opt.textContent.trim())) opt.remove();
        });
    }

    async function populateLegacySelect(select, endpoint) {
        if (!select || select.dataset.g1tPopulated === '1') return;
        select.dataset.g1tPopulated = '1';
        try {
            var response = await fetch(endpoint + '?q=&max=100&page=1', {
                credentials: 'include', cache: 'no-store'
            });
            if (!response.ok) return;
            var data = await response.json();
            (data.results || []).forEach(function (item) {
                if (select.querySelector('option[value="' + String(item.id).replace(/"/g, '\\"') + '"]')) return;
                var opt = document.createElement('option');
                opt.value = item.id;
                opt.textContent = item.title || item.text || item.username || item.id;
                select.appendChild(opt);
            });
        } catch (e) {
            console.error('GLOBAL1TEL dropdown load error:', e);
        }
    }

    function populateLegacyFilters() {
        cleanLegacyAgentOptions();
        var role = roleFromPath();
        document.querySelectorAll('select[name="fagent"]').forEach(function (s) {
            populateLegacySelect(s, 'res/aj_agents.php');
        });
        document.querySelectorAll('select[name="fclient"]').forEach(function (s) {
            populateLegacySelect(s, 'res/aj_clients.php');
        });
        document.querySelectorAll('select[name="frange"], select#drange').forEach(function (s) {
            populateLegacySelect(s, 'res/aj_smsranges.php');
        });
        document.querySelectorAll('select#xclient').forEach(function (s) {
            populateLegacySelect(s, role === 'manager' ? 'res/aj_agents.php' : 'res/aj_clients.php');
        });
    }


    async function populateProfilePage() {
        if (!/\/Profile(?:\.html)?$/i.test(window.location.pathname)) return;
        try {
            var response = await fetch('/api/profile.php?action=get', {
                credentials: 'include', cache: 'no-store'
            });
            if (!response.ok) return;
            var data = await response.json();
            var profile = data.profile || {};
            var values = {
                name: profile.full_name || '',
                email: profile.email || '',
                contact: profile.phone || '',
                company: profile.company || '',
                address: profile.address || ''
            };
            Object.keys(values).forEach(function (name) {
                var el = document.querySelector('form input[name="' + name + '"], form textarea[name="' + name + '"]');
                if (el) el.value = values[name];
            });
        } catch (e) {
            console.error('GLOBAL1TEL profile load error:', e);
        }
    }


    function pad2(n) { return String(n).padStart(2, '0'); }
    function fmtDate(d, withTime, endOfDay) {
        var base = d.getFullYear() + '-' + pad2(d.getMonth()+1) + '-' + pad2(d.getDate());
        if (!withTime) return base;
        return base + (endOfDay ? ' 23:59:59' : ' 00:00:00');
    }

    function refreshLegacyDateDefaults() {
        var now = new Date();
        var start = new Date(now.getTime());
        start.setDate(start.getDate() - 30);
        document.querySelectorAll('input[name="fdate1"], input[name="fdate2"]').forEach(function(el) {
            var old = String(el.value || '');
            if (!/^2026-(04|05)-/.test(old)) return;
            var withTime = /\d{2}:\d{2}:\d{2}/.test(old);
            if (el.name === 'fdate1') el.value = fmtDate(start, withTime, false);
            if (el.name === 'fdate2') el.value = fmtDate(now, withTime, true);
        });
    }

    function enableLegacyFilters() {
        document.addEventListener('submit', function(event) {
            var form = event.target;
            if (!form || form.id !== 'fform' || !window.jQuery || !jQuery.fn.dataTable) return;
            var tableEl = jQuery('#dt');
            if (!tableEl.length || !jQuery.fn.dataTable.isDataTable(tableEl[0])) return;
            event.preventDefault();
            var table = tableEl.dataTable();
            var settings = table.fnSettings();
            if (!settings || !settings.sAjaxSource) return;
            var current = settings.sAjaxSource;
            var base = current.split('?')[0];
            var keep = [];
            var match = current.match(/[?&](view=[^&]+)/);
            if (match) keep.push(match[1]);
            var params = jQuery(form).serialize();
            settings.sAjaxSource = base + '?' + [params].concat(keep).filter(Boolean).join('&');
            table.fnDraw();
        }, true);
    }

    function getCachedUsername() {
        try {
            return (window.localStorage && localStorage.getItem('global1tel_username')) || '';
        } catch (e) {
            return '';
        }
    }

    function cacheUsername(username) {
        try {
            if (window.localStorage && username) localStorage.setItem('global1tel_username', username);
        } catch (e) {}
    }

    async function loadSession() {
        // Use the last known username immediately so there is no Loading flash.
        var cachedUsername = getCachedUsername();
        if (cachedUsername) {
            setNavUsername(cachedUsername);
            setSidebarUsername(cachedUsername);
        }

        try {
            var response = await fetch('/api/session.php', {
                credentials: 'include', cache: 'no-store'
            });
            if (!response.ok) {
                window.location.replace('/ints/login');
                return;
            }

            var data = await response.json();
            if (!data.authenticated && !data.logged_in) {
                window.location.replace('/ints/login');
                return;
            }

            var user = data.user || data;
            if (!user || !user.username) {
                window.location.replace('/ints/login');
                return;
            }

            var expected = roleFromPath();
            var actual = String(user.role || '').toLowerCase();
            if (expected && actual && expected !== actual) {
                window.location.replace(dashboardFor(actual));
                return;
            }

            cacheUsername(user.username);
            setNavUsername(user.username);
            setSidebarUsername(user.username);
            updateSidebarClock();

            var usdBalance = document.getElementById('usd-balance');
            if (usdBalance && user.balances) {
                var usd = Number(user.balances.USD || 0);
                usdBalance.textContent = usd.toFixed(3);
            }

            var panelUrl = document.getElementById('panelurl');
            var callbackUrl = document.getElementById('callbackurl');
            var configPanelUrl = document.getElementById('configpanelurl');
            var configPanelPort = document.getElementById('configpanelport');
            if (panelUrl) panelUrl.textContent = window.location.origin;
            if (callbackUrl) callbackUrl.textContent = window.location.origin + '/api/smpp?action=receive';
            if (configPanelUrl && !configPanelUrl.value) configPanelUrl.value = window.location.protocol + '//' + window.location.hostname;
            if (configPanelPort && !configPanelPort.value) configPanelPort.value = window.location.port || (window.location.protocol === 'https:' ? '443' : '80');

            populateLegacyFilters();
            populateProfilePage();
        } catch (e) {
            console.error('GLOBAL1TEL session UI error:', e);
        }
    }

    function logout() {
        window.location.href = '/ints/logout';
    }


    /*
     * Reliable mobile top navigation.
     * The legacy Bootstrap data-api can miss taps after the responsive header
     * is repositioned. Handle only the two top-bar controls directly while
     * leaving every page action and backend flow untouched.
     */
    /*
     * Role-isolated mobile main menu.
     * Some legacy pages contain a stale Client menu inside .nav-collapse even
     * when the page itself belongs to Agent/Manager. Rebuild that mobile menu
     * from the current role's sidebar so one panel can never display another
     * panel's navigation options.
     */
    function isolateRoleMobileMenu() {
        var role = roleFromPath();
        if (!role) return;

        var navbar = document.querySelector('.navbar.navbar-fixed-top');
        var navCollapse = navbar ? navbar.querySelector('.nav-collapse') : null;
        var sidebar = document.querySelector('#sidebar ul.side-nav');
        if (!navbar || !navCollapse || !sidebar) return;

        var mobileList = document.createElement('ul');
        mobileList.className = 'nav g1t-role-mobile-nav';
        mobileList.setAttribute('data-g1t-role', role);

        Array.prototype.forEach.call(sidebar.children, function (item) {
            if (!item || String(item.tagName).toLowerCase() !== 'li') return;
            var clone = item.cloneNode(true);

            // Avoid duplicate DOM ids after cloning sidebar items.
            if (clone.removeAttribute) clone.removeAttribute('id');
            Array.prototype.forEach.call(clone.querySelectorAll('[id]'), function (node) {
                node.removeAttribute('id');
            });

            mobileList.appendChild(clone);
        });

        if (!mobileList.children.length) return;

        while (navCollapse.firstChild) navCollapse.removeChild(navCollapse.firstChild);
        navCollapse.appendChild(mobileList);
        navCollapse.setAttribute('data-g1t-role', role);
        navbar.setAttribute('data-g1t-role', role);
    }

    function installTopNavClickFix() {
        var navbar = document.querySelector('.navbar.navbar-fixed-top');
        if (!navbar || navbar.dataset.g1tTopNavFixed === '1') return;
        navbar.dataset.g1tTopNavFixed = '1';

        var menuButton = navbar.querySelector('.btn.btn-navbar[data-toggle="collapse"]');
        var navCollapse = navbar.querySelector('.nav-collapse');
        var userItem = navbar.querySelector('ul.nav.pull-right > li.dropdown');
        var userToggle = userItem ? userItem.querySelector(':scope > a.dropdown-toggle') : null;

        function closeUserMenu() {
            if (!userItem) return;
            userItem.classList.remove('open');
            if (userToggle) userToggle.setAttribute('aria-expanded', 'false');
        }

        function closeMainMenu() {
            if (!navCollapse) return;
            navCollapse.classList.remove('in');
            if (menuButton) {
                menuButton.classList.remove('active');
                menuButton.setAttribute('aria-expanded', 'false');
            }
        }

        if (menuButton && navCollapse) {
            menuButton.setAttribute('aria-expanded', navCollapse.classList.contains('in') ? 'true' : 'false');

            menuButton.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (typeof event.stopImmediatePropagation === 'function') {
                    event.stopImmediatePropagation();
                }

                var opening = !navCollapse.classList.contains('in');
                navCollapse.classList.toggle('in', opening);
                menuButton.classList.toggle('active', opening);
                menuButton.setAttribute('aria-expanded', opening ? 'true' : 'false');

                if (opening) closeUserMenu();
            }, true);
        }

        if (userToggle && userItem) {
            userToggle.setAttribute('aria-expanded', userItem.classList.contains('open') ? 'true' : 'false');

            /* GLOBAL1TEL: plain click no longer opens the user menu — it's
               press-and-hold only (see custom-script.js). A click here
               still closes it if it happens to be open, and still
               prevents the default '#' link navigation. */
            userToggle.addEventListener('click', function (event) {
                event.preventDefault();
                event.stopPropagation();
                if (typeof event.stopImmediatePropagation === 'function') {
                    event.stopImmediatePropagation();
                }

                if (userItem.classList.contains('open')) {
                    closeUserMenu();
                }
            }, true);
        }

        document.addEventListener('click', function (event) {
            if (userItem && userItem.classList.contains('open') && !userItem.contains(event.target)) {
                closeUserMenu();
            }
        });

        document.addEventListener('keydown', function (event) {
            if (event.key === 'Escape' || event.keyCode === 27) {
                closeUserMenu();
                closeMainMenu();
            }
        });
    }

    document.addEventListener('click', function (event) {
        var a = event.target.closest('a');
        if (!a || !/\bLogout\b/i.test(a.textContent || '')) return;
        event.preventDefault();
        logout();
    });

    document.addEventListener('DOMContentLoaded', function () {
        isolateRoleMobileMenu();
        installTopNavClickFix();
        refreshLegacyDateDefaults();
        enableLegacyFilters();
        loadSession();
        updateSidebarClock();
        setInterval(updateSidebarClock, 1000);
    });
})();

/* GLOBAL1TEL: profile dropdown click fallback only.
   Keeps every other page/control untouched. */
(function () {
    'use strict';

    function getProfileParts() {
        var item = document.querySelector('.navbar.navbar-fixed-top ul.nav.pull-right > li.dropdown');
        if (!item) return null;
        var toggle = item.querySelector('a.dropdown-toggle');
        var menu = item.querySelector('ul.dropdown-menu');
        if (!toggle || !menu) return null;
        return { item: item, toggle: toggle, menu: menu };
    }

    function isOpen(parts) {
        if (!parts) return false;
        return parts.item.classList.contains('open') ||
            parts.menu.style.getPropertyValue('display') === 'block';
    }

    function openMenu(parts) {
        if (!parts) return;
        parts.item.classList.add('open');
        parts.toggle.setAttribute('aria-expanded', 'true');
        parts.menu.style.setProperty('display', 'block', 'important');
        parts.menu.style.setProperty('visibility', 'visible', 'important');
        parts.menu.style.setProperty('opacity', '1', 'important');
        parts.menu.style.setProperty('pointer-events', 'auto', 'important');
    }

    function closeMenu(parts) {
        if (!parts) return;
        parts.item.classList.remove('open');
        parts.toggle.setAttribute('aria-expanded', 'false');
        parts.menu.style.removeProperty('display');
        parts.menu.style.removeProperty('visibility');
        parts.menu.style.removeProperty('opacity');
        parts.menu.style.removeProperty('pointer-events');
    }

    /* GLOBAL1TEL: click-to-open fallback disabled on purpose — the menu is
       press-and-hold only now (see custom-script.js). Only the close
       handlers below stay active. */

    document.addEventListener('click', function (event) {
        var parts = getProfileParts();
        if (!parts || !isOpen(parts)) return;
        if (!parts.item.contains(event.target)) closeMenu(parts);
    }, false);

    document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape' && event.keyCode !== 27) return;
        closeMenu(getProfileParts());
    }, false);
})();

/* G1T_HAMBURGER_MAIN_MENU_PRIORITY_FIX_START
 * Scope: white three-line top button only.
 * Gives the hamburger tap priority over the profile control and opens the
 * existing dark main navigation. No page/backend/style logic is changed.
 */
(function () {
    'use strict';

    var lastPointerToggle = 0;

    function parts() {
        var navbar = document.querySelector('.navbar.navbar-fixed-top');
        if (!navbar) return null;
        var button = navbar.querySelector('.btn.btn-navbar[data-toggle="collapse"]');
        var menu = navbar.querySelector('.nav-collapse');
        if (!button || !menu) return null;
        return {
            navbar: navbar,
            button: button,
            menu: menu,
            profileItem: navbar.querySelector('ul.nav.pull-right > li.dropdown')
        };
    }

    function closeProfile(p) {
        var item = p && p.profileItem;
        if (!item) return;
        item.classList.remove('open');
        item.classList.remove('g1t-profile-open');
        var toggle = item.querySelector('a.dropdown-toggle');
        var dropdown = item.querySelector('ul.dropdown-menu');
        if (toggle) toggle.setAttribute('aria-expanded', 'false');
        if (dropdown) {
            dropdown.style.removeProperty('display');
            dropdown.style.removeProperty('visibility');
            dropdown.style.removeProperty('opacity');
            dropdown.style.removeProperty('pointer-events');
        }
    }

    function setSubmenus(menu, open) {
        menu.querySelectorAll('ul.acitem').forEach(function (sub) {
            if (open) {
                if (!Object.prototype.hasOwnProperty.call(sub.dataset, 'g1tHamburgerOldDisplay')) {
                    sub.dataset.g1tHamburgerOldDisplay = sub.style.display || '';
                }
                sub.style.setProperty('display', 'block', 'important');
            } else {
                var old = sub.dataset.g1tHamburgerOldDisplay;
                sub.style.removeProperty('display');
                if (old) sub.style.display = old;
                delete sub.dataset.g1tHamburgerOldDisplay;
            }
        });
    }

    function setMenu(p, open) {
        closeProfile(p);
        p.button.classList.remove('active');
        p.button.setAttribute('aria-expanded', open ? 'true' : 'false');
        p.menu.classList.toggle('in', open);

        if (open) {
            setSubmenus(p.menu, true);
            p.menu.style.setProperty('display', 'block', 'important');
            p.menu.style.setProperty('height', 'auto', 'important');
            p.menu.style.setProperty('overflow', 'visible', 'important');
        } else {
            setSubmenus(p.menu, false);
            p.menu.style.removeProperty('display');
            p.menu.style.removeProperty('height');
            p.menu.style.removeProperty('overflow');
        }
    }

    function isButtonTarget(target, p) {
        return !!(target && p && (target === p.button || p.button.contains(target)));
    }

    function handle(event, kind) {
        var p = parts();
        if (!isButtonTarget(event.target, p)) return;

        var now = Date.now();
        if (kind === 'click' && now - lastPointerToggle < 700) {
            event.preventDefault();
            event.stopPropagation();
            if (event.stopImmediatePropagation) event.stopImmediatePropagation();
            return;
        }
        if (kind === 'pointer') lastPointerToggle = now;

        event.preventDefault();
        event.stopPropagation();
        if (event.stopImmediatePropagation) event.stopImmediatePropagation();

        setMenu(p, !p.menu.classList.contains('in'));
    }

    function prioritizeButton() {
        var p = parts();
        if (!p) return;
        /* The profile control previously had the higher z-index. */
        p.button.style.setProperty('z-index', '30060', 'important');
        p.button.setAttribute('aria-expanded', p.menu.classList.contains('in') ? 'true' : 'false');
    }

    document.addEventListener('pointerup', function (event) {
        handle(event, 'pointer');
    }, true);

    document.addEventListener('click', function (event) {
        handle(event, 'click');
    }, true);

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', prioritizeButton, { once: true });
    } else {
        prioritizeButton();
    }
})();
/* G1T_HAMBURGER_MAIN_MENU_PRIORITY_FIX_END */

/* G1T_MOBILE_MAIN_MENU_PUSH_CONTENT_V1_START
 * Scope: mobile hamburger/main-navigation vertical push behavior only.
 * When the existing dark .nav-collapse opens, increase the outer navbar's
 * normal-flow height so the page content moves down. On close, restore the
 * original height. No page actions, profile menu, table, or backend logic is changed.
 */
(function () {
    'use strict';

    function mobileOnly() {
        return !window.matchMedia || window.matchMedia('(max-width: 979px)').matches;
    }

    function getParts() {
        var navbar = document.querySelector('.navbar.navbar-fixed-top');
        if (!navbar) return null;
        var header = navbar.querySelector('.navbar-inner.top-nav');
        var menu = navbar.querySelector('.nav-collapse');
        if (!header || !menu) return null;
        return { navbar: navbar, header: header, menu: menu };
    }

    function clearPush(p) {
        if (!p) return;
        p.navbar.style.removeProperty('height');
        p.navbar.style.removeProperty('min-height');
    }

    function syncPush() {
        var p = getParts();
        if (!p) return;

        if (!mobileOnly() || !p.menu.classList.contains('in')) {
            clearPush(p);
            return;
        }

        /* Measure after the existing hamburger code has made the menu visible
           and expanded its legacy submenus. */
        window.requestAnimationFrame(function () {
            if (!p.menu.classList.contains('in')) {
                clearPush(p);
                return;
            }

            var headerHeight = Math.ceil(p.header.getBoundingClientRect().height || 74);
            var menuHeight = Math.ceil(Math.max(
                p.menu.scrollHeight || 0,
                p.menu.getBoundingClientRect().height || 0
            ));
            var total = Math.max(headerHeight, headerHeight + menuHeight);

            p.navbar.style.setProperty('height', total + 'px', 'important');
            p.navbar.style.setProperty('min-height', total + 'px', 'important');
        });
    }

    function install() {
        var p = getParts();
        if (!p || p.navbar.dataset.g1tPushMenuInstalled === '1') return;
        p.navbar.dataset.g1tPushMenuInstalled = '1';

        var observer = new MutationObserver(function () {
            syncPush();
        });
        observer.observe(p.menu, {
            attributes: true,
            attributeFilter: ['class', 'style'],
            subtree: true
        });

        if (window.ResizeObserver) {
            var resizeObserver = new ResizeObserver(function () {
                if (p.menu.classList.contains('in')) syncPush();
            });
            resizeObserver.observe(p.menu);
        }

        window.addEventListener('resize', syncPush, { passive: true });
        window.addEventListener('orientationchange', syncPush, { passive: true });
        syncPush();
    }

    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', install, { once: true });
    } else {
        install();
    }
})();
/* G1T_MOBILE_MAIN_MENU_PUSH_CONTENT_V1_END */
