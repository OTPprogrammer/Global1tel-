(function () {
    'use strict';

    function roleFromPath() {
        var p = location.pathname.toLowerCase();
        if (p.indexOf('/ints/manager/') !== -1) return 'manager';
        if (p.indexOf('/ints/agent/') !== -1) return 'agent';
        if (p.indexOf('/ints/client/') !== -1) return 'client';
        return '';
    }

    function esc(value) {
        var div = document.createElement('div');
        div.textContent = value == null ? '' : String(value);
        return div.innerHTML;
    }

    function setStat(label, value) {
        document.querySelectorAll('.stat-block').forEach(function (block) {
            var spans = block.querySelectorAll('.stat-count span');
            if (spans.length >= 2 && spans[0].textContent.trim() === label) {
                spans[1].textContent = Number(value || 0).toLocaleString();
            }
        });
    }

    function setSummary(label, value) {
        document.querySelectorAll('.summary li').forEach(function (li) {
            var title = li.querySelector('.summary-title');
            var count = li.querySelector('.count');
            if (title && count && title.textContent.trim() === label) {
                count.textContent = Number(value || 0).toLocaleString();
            }
        });
    }

    function replaceTable(id, rows) {
        var selector = '#' + id;
        try {
            if (window.jQuery && jQuery.fn && jQuery.fn.dataTable && jQuery.fn.dataTableSettings) {
                var table = jQuery(selector).dataTable();
                if (table && typeof table.fnClearTable === 'function') {
                    table.fnClearTable();
                    if (rows.length && typeof table.fnAddData === 'function') table.fnAddData(rows);
                    return;
                }
            }
        } catch (e) {
            console.warn('GLOBAL1TEL table refresh fallback:', e);
        }
        var tbody = document.querySelector(selector + ' tbody');
        if (tbody) {
            tbody.innerHTML = rows.map(function (row) {
                return '<tr>' + row.map(function (cell) { return '<td>' + cell + '</td>'; }).join('') + '</tr>';
            }).join('');
        }
    }

    function updateChart(rows) {
        if (!window.jQuery || typeof jQuery.jqplot === 'undefined') return;
        var data = (rows || []).map(function (row) {
            return [row.date, parseInt(row.count, 10) || 0];
        });
        if (!data.length) {
            for (var i = 6; i >= 0; i--) {
                var d = new Date();
                d.setDate(d.getDate() - i);
                data.push([d.toISOString().slice(0, 10), 0]);
            }
        }
        jQuery('#chart1').empty();
        jQuery.jqplot('chart1', [data], {
            title: 'SMS LAST 7 DAYS',
            axes: {
                xaxis: { renderer: jQuery.jqplot.DateAxisRenderer, tickOptions: { formatString: '%b&nbsp;%#d' } },
                yaxis: { tickOptions: { formatString: '%.0f' } }
            },
            seriesDefaults: { show: true, xaxis: 'xaxis', yaxis: 'yaxis', lineWidth: 3, shadow: false },
            highlighter: { show: true, sizeAdjust: 7.5 },
            grid: { background: '#fff', drawBorder: false, shadow: false, gridLineColor: '#ccc', gridLineWidth: 1 },
            cursor: { show: false }
        });
    }

    function updateNews(news) {
        var rows = (news || []).slice(0, 5).map(function (item) {
            var date = item.created_at ? new Date(item.created_at.replace(' ', 'T')).toLocaleString() : '-';
            return [esc(date), esc(item.title || '-'), esc(item.content || '-')];
        });
        replaceTable('dbdt', rows);
    }

    function updateRecent(role, stats) {
        if (role === 'agent') {
            var rows = (stats.recent_clients || []).slice(0, 5).map(function (u) {
                var status = String(u.status || '') === 'active'
                    ? "<span class='label label-success'>Active</span>"
                    : "<span class='label label-important'>Inactive</span>";
                var id = parseInt(u.id, 10) || 0;
                var actions = "<a href='#' id='viewuser' info='" + id + "' class='btn btn-mini btn-info'><i class='icon-eye-open'></i></a> " +
                              "<a href='#' id='edituser' info='" + id + "' class='btn btn-mini btn-warning'><i class='icon-edit'></i></a>";
                return [esc(u.username || '-'), esc(u.email || '-'), esc(u.phone || '-'), status, actions];
            });
            replaceTable('dbdt1', rows);
        } else if (role === 'client') {
            var ranges = (stats.recent_ranges || []).slice(0, 20).map(function (r) {
                return [esc(r.range_name || '-'), esc(r.test_number || '-')];
            });
            replaceTable('dbdt1', ranges);
        }
    }

    function applyStats(role, stats) {
        if (role === 'agent') {
            setStat('Today SMS', stats.today_sms_total != null ? stats.today_sms_total : stats.today_sms);
            setStat('SMS Yesterday', stats.yesterday_sms);
            setStat('SMS This Week', stats.last_7_days_sms);
            setStat('SMS This Month', stats.month_sms_total != null ? stats.month_sms_total : stats.month_sms);
            setSummary('Total Clients', stats.total_clients);
            setSummary('Assigned Numbers', stats.assigned_numbers);
            setSummary('Today SMS', stats.today_sms_total != null ? stats.today_sms_total : stats.today_sms);
        } else if (role === 'client') {
            setStat('Today SMS', stats.today_sms);
            setStat('Last 7 Day SMS', stats.last_7_days_sms);
            setStat('Last 30 Day SMS', stats.last_30_days_sms);
            setSummary('Assigned Numbers', stats.assigned_numbers);
            setSummary('SMS This Month', stats.month_sms);
        }
        updateNews(stats.news || []);
        updateRecent(role, stats);
    }

    async function load() {
        var role = roleFromPath();
        if (role !== 'agent' && role !== 'client') return;
        try {
            var statsResponse = await fetch('/api/dashboard?action=stats', { credentials: 'include', cache: 'no-store' });
            var statsJson = await statsResponse.json();
            if (statsResponse.ok && statsJson.success && statsJson.stats) applyStats(role, statsJson.stats);

            var chartResponse = await fetch('/api/dashboard?action=chart&type=sms&period=7days', { credentials: 'include', cache: 'no-store' });
            var chartJson = await chartResponse.json();
            if (chartResponse.ok && chartJson.success) updateChart(chartJson.data || []);
        } catch (e) {
            console.error('GLOBAL1TEL dashboard refresh failed:', e);
        }
    }

    document.addEventListener('DOMContentLoaded', function () {
        window.setTimeout(load, 250);
    });
})();
